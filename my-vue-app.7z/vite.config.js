// vite.config.js
import { resolve } from 'path';
import handlebars from 'vite-plugin-handlebars';

export default {
  root: 'src',
  publicDir: './public',
  build: {
    outDir: './dist'
  },
  plugins: [
    handlebars({
      partialDirectory: './partials',
    }),
  ],
};