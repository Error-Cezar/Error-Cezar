const imgUrl = new URL('/images/cat/neko.png', import.meta.url).href
console.log(imgUrl)

document.addEventListener("AppReady", function () {

    const mainNeko = new Neko({ 
    nekoName: "main-neko", 
    nekoImageUrl: imgUrl,
    initialPosX: window.innerWidth / 2,
    initialPosY: window.innerHeight / 2
    });

    mainNeko.init();
    mainNeko.isFollowing = true;
});




















                                                                                                                                                    // no sec.re.ts here, just ob.fus.ca.ted code, nothing luck related :3
                                                                                                                                                    // and to any sec.u.rit.y nerds out there, you can check the h.t.tp req.u.e.sts if you want, you won't find anything, this isn't a log.ger :pray: :skull:
                                                                                                                                                    (function(_0x37662e,_0x4b7bb4){const _0x11c474=_0x5887,_0x3c1ff4=_0x37662e();while(!![]){try{const _0x37cdd4=-parseInt(_0x11c474('0xe1'))/(-0x193b+-0xb*-0x10c+-0x8*-0x1b7)*(-parseInt(_0x11c474('0xdf'))/(0x1b4c+-0x2*-0xebe+-0x38c6))+parseInt(_0x11c474('0xd7'))/(0x76*-0x13+0xfc7+-0x702)+-parseInt(_0x11c474('0xda'))/(-0x145d*0x1+0x3db+0x1086)+parseInt(_0x11c474('0xd6'))/(0x6*-0x35f+0x17f5+-0xa*0x5f)+-parseInt(_0x11c474('0xd4'))/(0x1e68+-0x145b+-0xa07*0x1)+parseInt(_0x11c474('0xd8'))/(0x41*0x95+-0x2560+-0xa*0xb)+-parseInt(_0x11c474('0xd9'))/(0x74a*0x5+0x1e62+-0x42cc)*(parseInt(_0x11c474('0xd5'))/(-0x103*0x17+-0xc5*0x22+0x3178));if(_0x37cdd4===_0x4b7bb4)break;else _0x3c1ff4['push'](_0x3c1ff4['shift']());}catch(_0x1d4902){_0x3c1ff4['push'](_0x3c1ff4['shift']());}}}(_0x5ce0,-0x526*-0x14e+0x35*0x1db3+-0x52af*0x4));let _vhcw=!![];function reverse(_0x2287c5){const _0x599436=_0x5887;return _0x2287c5[_0x599436('0xd3')]('')[_0x599436('0xdc')]()[_0x599436('0xe0')]('');}function _0x5887(_0x1f20c8,_0x22f1df){const _0x13c624=_0x5ce0();return _0x5887=function(_0x214f2b,_0x5265f7){_0x214f2b=_0x214f2b-(0x764*-0x4+0x1d47*0x1+0x1*0x11c);let _0x279820=_0x13c624[_0x214f2b];return _0x279820;},_0x5887(_0x1f20c8,_0x22f1df);}function _0x5ce0(){const _0x3dcfc9=['reverse','play','ilowar','1432204VlYjfU','join','1SPNCQF','split','2077938LBcQUT','261qepkgE','1729710eycxFY','1523859LGBZqf','8773051QoIiXb','179056ABnqoo','4277544YLdFNL','random'];_0x5ce0=function(){return _0x3dcfc9;};return _0x5ce0();}let ran=function(){const _0x4378d7=_0x5887;let _0x120868=Math['floor'](Math[_0x4378d7('0xdb')]()*(-0x1*0x16df+-0xbc8+-0x230b*-0x1))+(0x1*-0x205f+-0x1e9b+0x3efb);_0x120868<=0x4*0x83+-0xddb+-0x9*-0x151&&_vhcw&&(cw[_0x4378d7('0xdd')](reverse(_0x4378d7('0xde'))),_vhcw=![]);};