import { Cron } from "croner";
import { Hono } from 'hono'
import { serveStatic, upgradeWebSocket, websocket } from 'hono/bun'
import type { WSContext } from 'hono/ws';
// -------
import { LastFMUser } from 'lastfm-ts-api';
// -------
import { Top } from './pages/main';

const FM_API = process.env.FM_API || ""
const FM_USER = process.env.FM_USER || ""
const user = new LastFMUser(FM_API);

let FM_LastFetch = {}
function WS_Fire(ws: WSContext<any>) {
  ws.send(JSON.stringify(FM_LastFetch))
}

// use fm api here
const FM_JOB = new Cron('*/3 * * * * *', () => {
  user.getRecentTracks({ user: FM_USER, limit: 2 }).then((value) => {
    // do stuff here
  }).catch(console.error);
});

const app = new Hono()
app.use('*', serveStatic({
	root: './public'
}));

app.get('/', (c) => {
	return c.html(<Top />)
})

const ws = app.get(
  '/fm',
  upgradeWebSocket((_c) => {
    let intervalId: string | number | NodeJS.Timeout | undefined
    return {
      onOpen(_event, ws) {
        WS_Fire(ws)
        intervalId = setInterval(() => {
          WS_Fire(ws)
        }, 4000)
      },
      onClose() {
        clearInterval(intervalId)
      },
    }
  })
)

export default {
	port: 3000,
	fetch: app.fetch,
	websocket
}