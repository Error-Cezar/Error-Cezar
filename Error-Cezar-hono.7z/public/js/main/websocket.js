console.log("websocket time")

// Get the current location
const currentLocation = window.location;

// Determine the WebSocket protocol based on the current protocol
const wsProtocol = currentLocation.protocol === 'https:' ? 'wss://' : 'ws://';

// Construct the WebSocket URL
const wsUrl = `${wsProtocol}${currentLocation.host}/fm`; // Adjust the path as needed

// Create a new WebSocket connection
const socket = new WebSocket(wsUrl);

// Event listener for when the connection is opened
socket.onopen = function(event) {
    console.log('WebSocket is open now.');
    // You can send a message to the server
    socket.send('Hello Server!');
};

// Event listener for when a message is received from the server
socket.onmessage = function(event) {
    console.log('Message from server:', event.data);
};

// Event listener for errors
socket.onerror = function(error) {
    console.error('WebSocket error:', error);
};

// Event listener for when the connection is closed
socket.onclose = function(event) {
    console.log('WebSocket is closed now.');
};