export const header = () => {
    return <>
        <div class="parent container h-100 d-flex flex-column justify-content-center">
            <h1 class="cover-heading rainbow-name" id="name">This idiot</h1>
            <div id="description">
                <p class="lead"><a id="idiot">An idiot</a> that does <a class="rainbow-text" style="text-decoration: none !important;" href="/projects">awesome things!!!</a>
                <br />
                that rainbow was NOT necessary, but I felt like it
                </p>
            </div>

            <div class="alert alert-warning" role="alert">
            I have a life, therefore im not a professional at making UI design
            don't complain about this site being bad, thanks
            </div>

            <div style="padding-top: 50px"></div>

            <div class="card-group text-center">
                <div class="card border-primary mb-3" style="max-width: 18rem;">
                    <div class="card-body text-primary">
                        <h5 class="card-title">European motherfucker</h5>
                        <p class="card-text">None of that american stuff here<br/>I have no clue what a mile is.<br/> <a>miles morales??????</a>
                        <p class="font-italic">haha GDPR go brrrrrrrr</p>
                        </p>
                    </div>
                </div>


                <div class="card border-primary mb-3" style="max-width: 18rem;">
                    <div class="card-body text-primary">
                        <h5 class="card-title">Cat</h5>
                        <p class="card-text">
                            Cat <br/>
                            Car <br/>
                            Cat <br/>
                            Car <br/>
                            Cat <br/>
                            Car <br/>
                        </p>
                    </div>
                </div>

                <div class="card border-primary mb-3" style="max-width: 18rem;">
                    <div class="card-body text-primary">
                        <h5 class="card-title">Nerd Activity</h5>
                        <p class="card-text">
                            Nerdy stuff, I think it's called <a class="text-warning font-weight-bold">programming</a> or something like that <br/><br/> grok is this true?
                        </p>
                    </div>
                </div>
            </div>

            <div style="padding-top: 50px"></div>

            <div class="alert alert-danger" role="alert">
                I plan on having more stuff here so I guess stay updated<br/>I wanted to add a list of programming languages but i felt lazy to add it on the moment
            </div>
        </div>
    </>
}