import { html } from "hono/html";

export const scripts = () => {
  return html`
  <script src="/js/about/name.js"></script>
  `
};
