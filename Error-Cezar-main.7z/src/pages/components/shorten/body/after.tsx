export const shortafter = () => {
    return (
        <>
            <script src="/js/short/main.js"></script>
        </>
    )
};