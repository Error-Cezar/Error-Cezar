export const content = () => {
    return <>
        <div style="padding-top: 50px"></div>

        {/* content */}
    </>
}