import { html } from "hono/html";

export const scripts = () => {
  return html`
  <script src="/js/projects/name.js"></script>
  `
};
