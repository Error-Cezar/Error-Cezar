const GLOBAL_SETTINGS = {
  UserID: "362991657236561923",
  music: true,
  AvatarFrame: false,
  Status: false,
  Tilt: false,

  Songs: [
    {
      name: "Start A War",
      src: "SAW.mp3",
    },
    {
      name: "FXCK UP THE WORLD",
      src: "FUTW.mp3",
    },
    {
      name: "Like That",
      src: "LikeThat.mp3",
    },
    {
      name: "Rather Lie",
      src: "RatherLie.mp3",
    },
    {
      name: "ExtraL",
      src: "ExtraL.mp3",
    },
    {
      name: "Runnin",
      src: "Runnin.mp3",
    },
    {
      name: "PUFF",
      src: "PUFF.mp3",
    },
    {
      name: "DDU-DU DDU-DU",
      src: "D4.mp3",
    },
    {
      name: "Forever Young",
      src: "FY.mp3",
    },
    {
      name: "Shut Down",
      src: "SD.mp3",
    },
    {
      name: "With The IE",
      src: "IE.mp3",
    },
  ],

  Titles: ["ErrorCezar", "errorcezar.lol", ":3 cho cho cho"],
  Title_Interval: 3000,

  usernameVariants: [
    "ErrorCezar",
    "The original code is a mess",
    "What is <strong><span style='color: red;'>LOVE</span>.</strong>",
    "08/02/2025 :3",
  ],
  usernameInterval: 3000,
};
