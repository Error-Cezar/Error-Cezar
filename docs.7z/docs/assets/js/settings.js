const GLOBAL_SETTINGS = {
    UserID: "362991657236561923",
    neko: false,
    music: true,
    AvatarFrame: false,
    Status: false,
    Tilt: false,

    Songs: [
    {
        name: "Like That",
        src: "LikeThat.mp3",
        cover: "LikeThat.jpg"
    },
    {
        name: "Rather Lie",
        src: "RatherLie.mp3",
        cover: "RatherLie.jpg"
    },
    {
        name: "ExtraL",
        src: "ExtraL.mp3",
        cover: "ExtraL.jpg"
    },
    {
        name: "Runnin",
        src: "Runnin.mp3",
        cover: "Runnin.jpg"
    },
        {
        name: "PUFF",
        src: "PUFF.mp3",
        cover: "PUFF.jpg"
    },
    {
        name: "DDU-DU DDU-DU",
        src: "D4.mp3",
        cover: "SU.jpg"
    },
        {
        name: "Forever Young",
        src: "FY.mp3",
        cover: "SU.jpg"
    },
    {
        name: "Shut Down",
        src: "SD.mp3",
        cover: "BP.jpg"
    }
    ],

    Titles: [
        "Ball's Bio",
        "Welcome to My World",
        "Explore and Enjoy"
    ],
    Title_Interval: 3000,

    usernameVariants: [
        "ErrorCezar",
        "The original code is a mess",
        "What is <span style='color: red;'>LOVE</span>.",
        "08/02/2025 :3",
    ],
    usernameInterval: 3000
};