export const before = () => {
    return (
        <before>
            <script src="/js/settings.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/cw@latest/dist/cw.min.js"></script>
            <script src="/js/main/detector.js"></script>
        </before>
    )
}