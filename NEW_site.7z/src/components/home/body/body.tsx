import { background } from "./body_elements/background";
import { box } from "./body_elements/box";
import { terminal, terminal_hide } from "./body_elements/terminal";

export const body_el = () => {
    return (
        <main>
            {terminal()}
            {terminal_hide()}
            {background()}
            {box()}
        </main>
    )
}