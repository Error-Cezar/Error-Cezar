export const terminal = () => {
    return (
            <div class="container" style="z-index: 10000">
                <div class="row justify-content-center">
                    <p class="text-white" id="terminal-text" style="font-size: 50px"></p>
                </div>
            </div>
    )
}

export const terminal_hide = () => {
    <div id="terminal-hide" aria-hidden="true"></div>
}