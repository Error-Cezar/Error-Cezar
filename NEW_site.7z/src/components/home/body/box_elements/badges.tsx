export const badges = () => {
    return (
        <div class="badges-container align-self-center">
            <img src="images/badge/love.png" alt="heart badge" />
        </div>
    )
}